<section id="home-token" class="home-token">
    <h2 id="title_page">Tokenomics</h2>
    <hr>
    <div class="container" id="tockennomics">
        <div class="sc-content">
            <div class="wow ">
                <div class="el__thumb">
                    <div class="dnfix__thumb -contain">
                        <img src="https://vikingdom.io/wp-content/themes/hello-theme-child-master/new-home/images/home-token.png"
                             alt="">
                    </div>
                </div>
            </div>
            <div class="el__excerpt wow fadeInUp">
                The dual chain architecture of BSC allows its users to effectively develop and build their own
                decentralized apps (dApps) and also digital assets on one blockchain. This is one feature that Vikingdom
                development targets. Moreover, dApps build on this smart chain can take advantage of this fast trading
                platform to exchange tokens just as fast between one another.
            </div>
            <div class="home-token__wallet wow fadeInUp">
            </div>
        </div>
    </div>
</section>

